
  # Dark Tech Dashboard UI

  This is a code bundle for Dark Tech Dashboard UI. The original project is available at https://www.figma.com/design/ZuCJ2mY6Fm5wTDTvJuuPgM/Dark-Tech-Dashboard-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  